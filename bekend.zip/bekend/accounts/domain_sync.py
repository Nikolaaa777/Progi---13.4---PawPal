from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from django.contrib.auth.models import User
from django.db import transaction

from .models import Vlasnik


@dataclass(frozen=True)
class VlasnikPayload:
    """Podaci koje želimo zapisati u tablicu "Vlasnik"."""
    email: str
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone: Optional[str] = None


def ensure_vlasnik_row(user: User, payload: Optional[VlasnikPayload] = None) -> Vlasnik:
    """Osiguraj da za danog Django user-a postoji red u tablici "Vlasnik".

    Mapiranje je po email-u (jer domena trenutno nema FK na auth_user).
    - Ako red ne postoji: kreira se.
    - Ako postoji: dopune se prazna polja (ime/prezime/telefon) kad su dostupna.
    """
    if payload is None:
        payload = VlasnikPayload(
            email=user.email,
            first_name=user.first_name or None,
            last_name=user.last_name or None,
            phone=None,
        )

    email_norm = (payload.email or "").strip().lower()
    if not email_norm:
        raise ValueError("Ne mogu kreirati Vlasnik bez email-a.")

    defaults = {
        "emailVlasnik": email_norm,
        "imeVlasnik": payload.first_name,
        "prezimeVlasnik": payload.last_name,
        "telefonVlasnik": payload.phone,
    }

    with transaction.atomic():
        vlasnik, _created = Vlasnik.objects.get_or_create(
            emailVlasnik__iexact=email_norm,
            defaults=defaults,
        )

        changed = False

        if payload.first_name and not vlasnik.imeVlasnik:
            vlasnik.imeVlasnik = payload.first_name
            changed = True
        if payload.last_name and not vlasnik.prezimeVlasnik:
            vlasnik.prezimeVlasnik = payload.last_name
            changed = True
        if payload.phone and not vlasnik.telefonVlasnik:
            vlasnik.telefonVlasnik = payload.phone
            changed = True

        if vlasnik.emailVlasnik != email_norm:
            vlasnik.emailVlasnik = email_norm
            changed = True

        if changed:
            vlasnik.save(update_fields=["emailVlasnik", "imeVlasnik", "prezimeVlasnik", "telefonVlasnik"])

    return vlasnik
